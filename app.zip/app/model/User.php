<?php

namespace app\model;

use think\Model;

class User extends Model
{
    protected $resultSetType = 'collection';

    public function play()
    {
        $user_id = $this->login();
        $user = $this->where('id', $user_id)->find();
        if ($user['play'] > 0) {
            User::update(['play'  => $user['play']-1], ['id' => $user_id]);
            return true;
        } else {
            return false;
        }
    }

    public function login()
    {
        $user_id = cookie('user_id');
        if (!$user_id) {
            return $this->addUser();
        }

        $user = $this->where('id', $user_id)->find();
        if ($user) {
            $user = $user->toArray();
            if ($user['play'] < 5 && date("Y/m/d", strtotime($user['login_time'])) != date("Y/m/d")) {
                User::update([
                    'play'  => 5,
                    'ip'  => $_SERVER['REMOTE_ADDR'],
                    'login_time' => date("Y/m/d h:i:s")
                ], ['id' => $user_id]);
            } else {
                User::update([
                    'ip'  => $_SERVER['REMOTE_ADDR'],
                    'login_time' => date("Y/m/d h:i:s")
                ], ['id' => $user_id]);
            }
            return $user_id;
        } else {
            return $this->addUser();
        }
    }

    public function addUser()
    {
        $this->data([
            "ip"   => $_SERVER['REMOTE_ADDR'],
            "ua"   => $_SERVER['HTTP_USER_AGENT'],
            "play" => 5,
            "login_time" => date("Y/m/d h:i:s"),
            "time" => date("Y/m/d h:i:s"),
        ]);
        $this->save();
        $user_id = $this->id;

        cookie('user_id', $user_id, 25920000);
        return $user_id;
    }
}

<?php

namespace app\controller;
use app\model\User;
use app\BaseController;
use think\facade\Db;
use think\facade\View;


class Index extends BaseController
{

    public function index($id = 3, $sequence = 1, $page = 1,$tg=false,$cookie = false)
    {
        if($cookie){
            cookie('user_id', $cookie, 25920000);
        }
        
        if ($tg) {
            if (!cookie('user_id')) {
                $User = new User;
                $User = $User->login();
                if (cookie('user_id') != $tg) {
                    Db::name('user')
                    ->where('id', $tg)
                    ->inc('play',5)
                    ->update();
                    Db::table('user_extension')->insert([
                        'user_id' => $tg,
                        'ip' => $_SERVER['REMOTE_ADDR'],
                        'ua' => $_SERVER['HTTP_USER_AGENT'],
                        'time' => date("Y/m/d h:i:s")
                    ]);
                }
            }
        }


        $video_type = Db::name('video_type')->where(1)->select();
        $video_type = [
            "list" => $video_type,
            "active" => $id,
            "sequence" => $sequence
        ];
        View::assign('nav_type', $video_type);


        switch ($sequence) {
            case '1':
                $sequence = 'rack_time';//上架时间
                break;
            case '2':
                $sequence = 'prev_num';//预览次数
                break;
        };
        $video_list =  Db::name('video_list')->where('classify_id', $id)->order($sequence, 'desc')->limit(($page - 1) * 24, 24)->select();
        $totalPages = Db::name('video_list')->where('classify_id', $id)->count();
        $totalPages = ceil($totalPages / 24);
        $video = [
            "list" => $video_list,
            "page" => createAsignPageList($page, $totalPages)
        ];
        View::assign('video', $video);

        return View::fetch("type");
    }

    public function type($id = 1, $sequence = 1, $page = 1)
    {

        $video_type = Db::name('video_type')->where(1)->select();
        $video_type = [
            "list" => $video_type,
            "active" => $id,
            "sequence" => $sequence
        ];
        View::assign('nav_type', $video_type);


        switch ($sequence) {
            case '1':
                $sequence = 'rack_time';//上架时间
                break;
            case '2':
                $sequence = 'prev_num';//预览次数
                break;
        };
        $video_list =  Db::name('video_list')->where('classify_id', $id)->order($sequence, 'desc')->limit(($page - 1) * 24, 24)->select();
        $totalPages = Db::name('video_list')->where('classify_id', $id)->count();
        $totalPages = ceil($totalPages / 24);
        $video = [
            "list" => $video_list,
            "page" => createAsignPageList($page, $totalPages)
        ];
        View::assign('video', $video);

        return View::fetch("type");
    }

    public function search($key = '臀', $page = 1)
    {
        // $xvideos = new xvideos;
        // $videos = $xvideos->search($key,$page - 1);
        // View::assign('data', $videos);
        // return View::fetch();
    }

    public function play($id)
    {
        $video =  Db::name('video_list')->where('id', $id)->find();
        $play = new User;
        $play = $play->play();
        if(!$play){
            $video['m3u8_link'] = false;
        }else{
            Db::name('video_list')->where('id', $id)->inc('prev_num')->update();
        }

        View::assign('play', $video);
        return View::fetch();
    }

    public function hello($name = 'ThinkPHP6')
    {
        return 'hello,' . $name;
    }
}

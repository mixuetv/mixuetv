<?php

namespace app\controller;

use app\BaseController;
use app\model\User as ModelUser;
use think\facade\Db;
use think\facade\View;


class User extends BaseController
{

    public function index()
    {
        
        $user_id = cookie('user_id');
        $user_id = new ModelUser;
        $user_id = $user_id->login();

        $user = Db::table('user')->where('id', $user_id)->find();
        $total = Db::table('user_extension')->where('user_id', $user_id)->count();
        $today = Db::table('user_extension')->where('user_id', $user_id)->whereTime('time', 'today')->count();
        $user = [
            'play_num' => $user['play'],
            'statistics_total' => $total,
            'statistics_today' => $today,
            'extension_url' => "https://" . $_SERVER['HTTP_HOST'] . "/?tg=" . $user_id
        ];
        View::assign('user', $user);
        return View::fetch();
    }


}

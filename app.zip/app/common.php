<?php
// 应用公共文件




function createAsignPageList($currentPage, $totalPages)
{
    //总页数
    $totalPages = $totalPages;
    //展示页数     
    $disnum = 5;
    //开始位置     
    //$forstart; 
    //结束位置     
    //$forend;
    //开始位置计算 
    $forstart = round($currentPage - $disnum / 2);
    //开始位置最小值处理     
    if ($forstart <= 0) {
        $forstart = 1;
    }
    //结束位置计算
    $forend = $forstart + round($disnum / 2);
    if ($disnum > $forend - $forstart) {
        $forend = $forend + ($disnum - ($forend - $forstart) - 1);
    }
    //结束位置最大值处理，不能大于总页数     
    if ($forend > $totalPages) {
        //调整开始位置
        $forstart = $forstart - ($forend - $totalPages);
        $forend = $totalPages;
    }
    //开始位置最小值处理     
    if ($forstart <= 0) {
        $forstart = 1;
    }
    $arr[0] = [
        "title"   => "首页",
        "page"    => 1,
        "current" => false
    ];
    for ($i = $forstart; $i <= $forend; $i++) {
        if ($i == $currentPage) {
            array_push($arr, [
                "title"   => $i,
                "page"    => $i,
                "current" => true
            ]);
        } else {
            array_push($arr, [
                "title"   => $i,
                "page"    => $i,
                "current" => false
            ]);
        }
    };
    array_push($arr, [
        "title"   => "尾页",
        "page"    => $totalPages,
        "current" => false
    ]);


    return $arr;
}
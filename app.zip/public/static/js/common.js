function search(){
    var key = $('#search').val();
    window.location.href = '/index/search/key/' + key + '.html'
}